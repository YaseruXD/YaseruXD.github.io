<?php
// Connect to database
$host = "localhost";
$user = "root";
$pass = "";
$db = "shop";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Delete item from cart if remove requested
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['remove_id'])) {
    $removeId = (int)$_POST['remove_id'];
    $stmt = $conn->prepare("DELETE FROM cart WHERE id = ?");
    $stmt->bind_param("i", $removeId);
    $stmt->execute();
    $stmt->close();
    header("Location: " . $_SERVER['PHP_SELF']); // Refresh to update dashboard
    exit();
}

// Insert product to cart
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['product'])) {
    $product = $_POST['product'];
    $quantity = (int)$_POST['quantity'];
    $price = (float)$_POST['price'];
    $total = $price * $quantity;

    $stmt = $conn->prepare("INSERT INTO cart (product_name, quantity, price, total) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("sidd", $product, $quantity, $price, $total);
    $stmt->execute();
    $stmt->close();
}

// Fetch cart items
$result = $conn->query("SELECT * FROM cart ORDER BY added_at DESC");
$cartItems = $result->fetch_all(MYSQLI_ASSOC);
$conn->close();
?>
<?php
    include("heading.html");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Coffee Menu</title>
    
    <link rel="stylesheet" href="CSS/menu.css">
</head>

<body>

    <div id="menu-container">

        <!-- Section Toggles -->
         <div class="section-toggle-container">
            <div class="section-toggle" onclick="showSection('iced-coffee-section')">Iced Coffee</div>
            <div class="section-toggle" onclick="showSection('milktea-section')">Milktea</div>
            <div class="section-toggle" onclick="showSection('fruit-tea-section')">Fruit Tea</div>
            <div class="section-toggle" onclick="showSection('fruit-soda-section')">Fruit Soda</div>
            <div class="section-toggle" onclick="showSection('frappe-section')">Frappe</div>
         </div>
        <!-- Iced Coffee Section -->

        

        <div id="iced-coffee-section" class="coffee-section active">

        <div class="product-container">
            <div class="product">
                <img src="image\coffee.png" alt="Caramel" class="image">
                <h3>Caramel</h3>
                <label>Size:</label><br>
                <select id="size-caramel">
                    <option value="16oz" data-price="110">16oz - ₱110</option>
                    <option value="22oz" data-price="140">22oz - ₱140</option>
                </select><br><br>
                <label>Qty:</label>
                <div class="quantity-box">
                    <button class="qty-btn minus" onclick="decreaseQuantity('quantity-caramel')">−</button>
                    <input type="number" id="quantity-caramel" class="qty-input" value="1" min="1">
                    <button class="qty-btn plus" onclick="increaseQuantity('quantity-caramel')">+</button>
                </div>
                <br><button class="cart" onclick="addToCart('caramel', 'size-caramel', 'quantity-caramel')">Add to Cart</button>
            </div>
            <div class="product">
                <img src="image\coffee.png" alt="Hazelnut" class="image">
                <h3>Hazelnut</h3>
                <label>Size:</label><br>
                <select id="size-hazelnut">
                    <option value="16oz" data-price="110">16oz - ₱110</option>
                    <option value="22oz" data-price="140">22oz - ₱140</option>
                </select><br><br>
                <label>Qty:</label>
                <div class="quantity-box">
                    <button class="qty-btn minus" onclick="decreaseQuantity('quantity-hazelnut')">−</button>
                    <input type="number" id="quantity-hazelnut" class="qty-input" value="1" min="1">
                    <button class="qty-btn plus" onclick="increaseQuantity('quantity-hazelnut')">+</button>
                </div>
                <br><button class="cart" onclick="addToCart('Hazelnut', 'size-hazelnut', 'quantity-hazelnut')">Add to Cart</button>
            </div>
            <div class="product">
                <img src="image\coffee.png" alt="Vanilla" class="image">
                <h3>Vanilla</h3>
                <label>Size:</label><br>
                <select id="size-vanilla">
                    <option value="16oz" data-price="110">16oz - ₱110</option>
                    <option value="22oz" data-price="140">22oz - ₱140</option>
                </select><br><br>
                <label>Qty:</label>
                <div class="quantity-box">
                    <button class="qty-btn minus" onclick="decreaseQuantity('quantity-vanilla')">−</button>
                    <input type="number" id="quantity-vanilla" class="qty-input" value="1" min="1">
                    <button class="qty-btn plus" onclick="increaseQuantity('quantity-vanilla')">+</button>
                </div>
                <br><button class="cart" onclick="addToCart('Vanilla', 'size-vanilla', 'quantity-vanilla')">Add to Cart</button>
            </div>
            <div class="product">
                <img src="image\coffee.png" alt="Salted Caramel" class="image">
                <h3>Salted Caramel</h3>
                <label>Size:</label><br>
                <select id="size-saltedcaramel">
                    <option value="16oz" data-price="110">16oz - ₱110</option>
                    <option value="22oz" data-price="140">22oz - ₱140</option>
                </select><br><br>
                <label>Qty:</label>
                <div class="quantity-box">
                    <button class="qty-btn minus" onclick="decreaseQuantity('quantity-saltedcaramel')">−</button>
                    <input type="number" id="quantity-saltedcaramel" class="qty-input" value="1" min="1">
                    <button class="qty-btn plus" onclick="increaseQuantity('quantity-saltedcaramel')">+</button>
                </div>
                <br><button class="cart" onclick="addToCart('Salted Caramel', 'size-saltedcaramel', 'quantity-saltedcaramel')">Add to Cart</button>
            </div>
            <div class="product">
                <img src="image\coffee.png" alt="Matcha Latte" class="image">
                <h3>Matcha Latte</h3>
                <label>Size:</label><br>
                <select id="size-matchalatte">
                    <option value="16oz" data-price="110">16oz - ₱110</option>
                    <option value="22oz" data-price="140">22oz - ₱140</option>
                </select><br><br>
                <label>Qty:</label>
                <div class="quantity-box">
                    <button class="qty-btn minus" onclick="decreaseQuantity('quantity-matchalatte')">−</button>
                    <input type="number" id="quantity-matchalatte" class="qty-input" value="1" min="1">
                    <button class="qty-btn plus" onclick="increaseQuantity('quantity-matchalatte')">+</button>
                </div>
                <br><button class="cart" onclick="addToCart('Matcha Latte', 'size-matchalatte', 'quantity-matchalatte')">Add to Cart</button>
            </div>
    
        </div>

        </div>
        

        <!-- Hot Coffee Section -->
        <div id="hot-coffee-section" class="coffee-section">
            <h3>Hot Coffee</h3>
            <!-- Cappuccino -->
            <div class="product">
                <img src="" alt="Cappuccino">
                <h3>Cappuccino</h3>
                <label>Size:</label><br>
                <select id="size-cappuccino">
                    <option value="16oz" data-price="100">16oz - ₱100</option>
                    <option value="22oz" data-price="130">22oz - ₱130</option>
                </select><br><br>
                <label>Qty:</label>
                <!-- Quantity Input -->
                <div class="quantity-box">
                    <button class="qty-btn minus" onclick="decreaseQuantity('quantity-cappuccino')">−</button>
                    <input type="number" id="quantity-cappuccino" class="qty-input" value="1" min="1" readonly>
                    <button class="qty-btn plus" onclick="increaseQuantity('quantity-cappuccino')">+</button>
                </div>
                <br><button onclick="addToCart('Cappuccino', 'size-cappuccino', 'quantity-cappuccino')">Add to Cart</button>
            </div>

            <!-- Caramel Macchiato -->
            <div class="product">
                <img src="https://via.placeholder.com/150" alt="Caramel Macchiato">
                <h3>Caramel Macchiato</h3>
                <label>Size:</label><br>
                <select id="size-macchiato">
                    <option value="16oz" data-price="120">16oz - ₱120</option>
                    <option value="22oz" data-price="150">22oz - ₱150</option>
                </select><br><br>
                <label>Qty:</label>
                <div class="quantity-box">
                    <button class="qty-btn minus" onclick="decreaseQuantity('quantity-macchiato')">−</button>
                    <input type="number" id="quantity-macchiato" class="qty-input" value="1" min="1" readonly>
                    <button class="qty-btn plus" onclick="increaseQuantity('quantity-macchiato')">+</button>
                </div>
                <button onclick="addToCart('Caramel Macchiato', 'size-macchiato', 'quantity-macchiato')">Add to Cart</button>
            </div>
        </div>

        <!-- Hidden form to submit selected product -->
        <form id="cartForm" method="POST" style="display:none;">
            <input type="hidden" name="product" id="formProduct">
            <input type="hidden" name="quantity" id="formQuantity">
            <input type="hidden" name="price" id="formPrice">
        </form>

        <!-- Cart Dashboard -->
        <div id="dashboard">
            <h2>Cart Dashboard</h2>
            <?php if (count($cartItems) > 0): ?>
            <table>
                <tr>
                    <th>Product</th>
                    <th>Qty</th>
                    <th>Price</th>
                    <th>Total</th>
                    <th>Added At</th>
                    <th>Action</th>
                </tr>
                <?php foreach ($cartItems as $item): ?>
                <tr>
                    <td>
                        <?= htmlspecialchars($item['product_name']) ?>
                    </td>
                    <td>
                        <?= $item['quantity'] ?>
                    </td>
                    <td>₱
                        <?= number_format($item['price'], 2) ?>
                    </td>
                    <td>₱
                        <?= number_format($item['total'], 2) ?>
                    </td>
                    <td>
                        <?= $item['added_at'] ?>
                    </td>
                    <td>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="remove_id" value="<?= $item['id'] ?>">
                            <button type="submit" class="remove-btn">Remove</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
            <?php else: ?>
            <p>No items in the cart yet.</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Payment Section -->
    <div id="payment-section">
        <h2>Payment</h2>
        <h3>Cart Items:</h3>
        <ul id="cart-items-list">
            <!-- Cart items will be added here dynamically -->
        </ul>
        <p>Total: ₱<span id="total-amount">0.00</span></p>

        <h3>Payment Options:</h3>
        <input type="radio" id="cash" name="payment_method" value="cash">
        <label for="cash">Cash</label><br>

        <input type="radio" id="gcash" name="payment_method" value="gcash">
        <label for="gcash">GCash</label><br><br>

        <button onclick="processPayment()">Process Payment</button>
    </div>

    <div id="overlay"></div>

    <script src="script/menu.js"></script>

</body>

</html>