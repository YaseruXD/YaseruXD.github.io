
        window.addEventListener('load', function () {
    showSection('iced-coffee-section'); // Show iced coffee section by default
    updateCartDisplay(); // Initial payment section update
});

// === Add to Cart ===
function addToCart(baseProduct, sizeId, quantityId) {
    const sizeSelect = document.getElementById(sizeId);
    const quantityInput = document.getElementById(quantityId);

    if (!sizeSelect || !quantityInput) return;

    const selected = sizeSelect.options[sizeSelect.selectedIndex];
    const size = selected.value;
    const price = parseFloat(selected.getAttribute('data-price'));
    const quantity = parseInt(quantityInput.value);

    if (isNaN(quantity) || quantity < 1) {
        alert("Please enter a valid quantity.");
        return;
    }

    const productName = baseProduct + " " + size;

    // Set form values
    document.getElementById("formProduct").value = productName;
    document.getElementById("formQuantity").value = quantity;
    document.getElementById("formPrice").value = price;

    // Submit the form
    document.getElementById("cartForm").submit();

    // Update Payment Section
    updateCartDisplay();
}

// === Update Cart Display ===
function updateCartDisplay() {
    const cartItemsList = document.getElementById("cart-items-list");
    const totalAmount = document.getElementById("total-amount");
    const dashboardTable = document.querySelector('#dashboard table');

    if (!cartItemsList || !totalAmount || !dashboardTable) return;

    cartItemsList.innerHTML = ""; // Clear previous items
    let total = 0;

    const rows = dashboardTable.querySelectorAll('tr');
    for (let i = 1; i < rows.length; i++) { // Skip header row
        const row = rows[i];
        const cells = row.querySelectorAll('td');
        const productName = cells[0].textContent;
        const quantity = parseInt(cells[1].textContent);
        const price = parseFloat(cells[2].textContent.replace('₱', '').replace(',', ''));
        const itemTotal = price * quantity;
        const itemId = getCartItemId(productName, quantity, price);

        total += itemTotal;

        const listItem = document.createElement("li");
        listItem.innerHTML = `${productName} x ${quantity} - ₱${itemTotal.toFixed(2)} 
            <button class="remove-btn" onclick="removeFromCart('${itemId}')">Remove</button>`;
        listItem.dataset.itemId = itemId;

        cartItemsList.appendChild(listItem);
    }

    totalAmount.textContent = total.toFixed(2);
}

// === Generate Unique Item ID ===
function getCartItemId(productName, quantity, price) {
    return productName.replace(/\s/g, '') + quantity + price;
}

// === Remove from Cart ===
function removeFromCart(itemId) {
    const listItem = document.querySelector(`#cart-items-list li[data-item-id="${itemId}"]`);
    if (listItem) {
        listItem.remove();
        removeCartItemFromDashboard(itemId);
        updateCartDisplay();
    }
}

function removeCartItemFromDashboard(itemId) {
    const dashboardTable = document.querySelector('#dashboard table');
    if (!dashboardTable) return;

    const rows = dashboardTable.querySelectorAll('tr');
    for (let i = 1; i < rows.length; i++) {
        const row = rows[i];
        const cells = row.querySelectorAll('td');
        const productName = cells[0].textContent;
        const quantity = parseInt(cells[1].textContent);
        const price = parseFloat(cells[2].textContent.replace('₱', '').replace(',', ''));
        const currentItemId = getCartItemId(productName, quantity, price);

        if (currentItemId === itemId) {
            const removeButton = row.querySelector('.remove-btn');
            if (removeButton) {
                removeButton.click(); // Trigger actual removal (if button exists)
            }
            break;
        }
    }
}

// === Process Payment ===
function processPayment() {
    const paymentMethod = document.querySelector('input[name="payment_method"]:checked');
    const totalAmount = document.getElementById("total-amount").textContent;

    if (paymentMethod) {
        alert("Payment processed using " + paymentMethod.value + " for ₱" + totalAmount);
        location.reload();
    } else {
        alert("Please select a payment method.");
    }
}

// === Section Toggle ===
function showSection(sectionID) {
    document.querySelectorAll(".coffee-section").forEach(section =>
        section.classList.remove('active')
    );
    document.getElementById(sectionID)?.classList.add('active');
}

// === Quantity Controls ===
function increaseQuantity(quantityId) {
    const input = document.getElementById(quantityId);
    if (input) input.value = parseInt(input.value) + 1;
}

function decreaseQuantity(quantityId) {
    const input = document.getElementById(quantityId);
    if (input) {
        let value = parseInt(input.value);
        if (value > 1) input.value = value - 1;
    }
}


